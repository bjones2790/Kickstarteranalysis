# Kickstarting with Excel

## Overview of Project

This project measures the outcomes of theater plays based on targeted funding goals. In this analysis we looked at outcomes based on launch date and targeted funding goals. 
Plays that met targeted funding goals were classifed as 'successful' while plays that fell below the targeted goal were classified as 'failed.' 


## Analysis and Challenges

### Analysis of Outcomes Based on Launch Date

The first analysis looke at outcomes throughout the year to identify trends or patterns as it relates to successful launch periods for theater plays. In this analysis we created a  
pivot table with added filters in order to avoid including irrelevant data points aside from "Year" and the parent category of "Theater". We then measured outcomes based on overall 'successful' 
'failed' and 'cancelled' outcomes.


### Analysis of Outcomes Based on Goals

The second analysis measured theater plays that successfuly met targeted funding goals. This analysis identified the percentage of plays that were 'successsful' or 'failed' to meet established goals. In this analysis
it was important to make sure the "countifs" formula is pulling from the correct range on the Kickstarter sheet. An easy way to avoid capturing unwanted data points is to apply a sorted filter of theater plats.

## Results

- What are two conclusions you can draw about the Outcomes based on Launch Date?

	 1). Plays launched between April and June have a greater likelihood of meeting established funding goals
	 2). Plays launched in December have an almost equal chance of either being successful or unsuccessful 

- What can you conclude about the Outcomes based on Goals?

	 1). Plays with funding goals of $20,000 or more have a greater likelihood of failing to meet targeted goals

- What are some limitations of this dataset?

A data dictionary to explain the various fields would be helpful for the analysis, particularly for the 'staff pick', 'backers count', and 'spotlight' categories. 

- What are some other possible tables and/or graphs that we could create?

We could also create a stacked bar chart, particularly to display the "Outcomes Based on Goal" data.
